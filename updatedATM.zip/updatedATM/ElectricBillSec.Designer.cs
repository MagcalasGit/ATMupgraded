﻿namespace updatedATM
{
    partial class ElectricBillSec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ElectricBillSec));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            electricChoice = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            PayBtn = new Guna.UI2.WinForms.Guna2Button();
            txtPayamount = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cheqorsavings = new Guna.UI2.WinForms.Guna2ComboBox();
            receiptPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblselectedCompany = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAccNum = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            continueBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBal = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAmountSubtracted = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblcheqorsavings = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            exitBtn = new Guna.UI2.WinForms.Guna2Button();
            receiptPanel.SuspendLayout();
            SuspendLayout();
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel2.Location = new Point(48, 408);
            guna2HtmlLabel2.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(254, 30);
            guna2HtmlLabel2.TabIndex = 14;
            guna2HtmlLabel2.Text = "Choose where to pay here:";
            // 
            // electricChoice
            // 
            electricChoice.AutoCompleteCustomSource.AddRange(new string[] { "Savings", "Cheque" });
            electricChoice.BackColor = Color.Transparent;
            electricChoice.BorderColor = Color.DarkSlateGray;
            electricChoice.BorderRadius = 10;
            electricChoice.BorderThickness = 2;
            electricChoice.CustomizableEdges = customizableEdges1;
            electricChoice.DrawMode = DrawMode.OwnerDrawFixed;
            electricChoice.DropDownStyle = ComboBoxStyle.DropDownList;
            electricChoice.FocusedColor = Color.FromArgb(94, 148, 255);
            electricChoice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            electricChoice.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            electricChoice.ForeColor = Color.Teal;
            electricChoice.ItemHeight = 30;
            electricChoice.Items.AddRange(new object[] { "Meralco", "Pelco", "Presco", "SFELAPCO" });
            electricChoice.Location = new Point(33, 440);
            electricChoice.Margin = new Padding(3, 4, 3, 4);
            electricChoice.Name = "electricChoice";
            electricChoice.ShadowDecoration.CustomizableEdges = customizableEdges2;
            electricChoice.Size = new Size(322, 36);
            electricChoice.TabIndex = 13;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Location = new Point(48, 301);
            guna2HtmlLabel1.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(191, 30);
            guna2HtmlLabel1.TabIndex = 12;
            guna2HtmlLabel1.Text = "Enter Amount Here:";
            // 
            // PayBtn
            // 
            PayBtn.BackColor = Color.Transparent;
            PayBtn.BorderColor = Color.DarkSlateGray;
            PayBtn.BorderRadius = 15;
            PayBtn.BorderThickness = 2;
            PayBtn.CustomizableEdges = customizableEdges3;
            PayBtn.DisabledState.BorderColor = Color.DarkGray;
            PayBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            PayBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            PayBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            PayBtn.FillColor = Color.Teal;
            PayBtn.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PayBtn.ForeColor = Color.White;
            PayBtn.Location = new Point(76, 582);
            PayBtn.Margin = new Padding(3, 4, 3, 4);
            PayBtn.Name = "PayBtn";
            PayBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            PayBtn.Size = new Size(241, 60);
            PayBtn.TabIndex = 11;
            PayBtn.Text = "Pay";
            PayBtn.Click += PayBtn_Click;
            // 
            // txtPayamount
            // 
            txtPayamount.BackColor = Color.Transparent;
            txtPayamount.BorderColor = Color.DarkSlateGray;
            txtPayamount.BorderRadius = 10;
            txtPayamount.BorderThickness = 2;
            txtPayamount.CustomizableEdges = customizableEdges5;
            txtPayamount.DefaultText = "";
            txtPayamount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPayamount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPayamount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPayamount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPayamount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPayamount.Font = new Font("Segoe UI", 9F);
            txtPayamount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPayamount.Location = new Point(33, 332);
            txtPayamount.Margin = new Padding(3, 5, 3, 5);
            txtPayamount.Name = "txtPayamount";
            txtPayamount.PasswordChar = '\0';
            txtPayamount.PlaceholderText = "";
            txtPayamount.SelectedText = "";
            txtPayamount.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtPayamount.Size = new Size(322, 68);
            txtPayamount.TabIndex = 10;
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel3.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel3.Location = new Point(48, 490);
            guna2HtmlLabel3.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(247, 30);
            guna2HtmlLabel3.TabIndex = 16;
            guna2HtmlLabel3.Text = "Choose account to pay in:";
            // 
            // cheqorsavings
            // 
            cheqorsavings.AutoCompleteCustomSource.AddRange(new string[] { "Savings", "Cheque" });
            cheqorsavings.BackColor = Color.Transparent;
            cheqorsavings.BorderColor = Color.DarkSlateGray;
            cheqorsavings.BorderRadius = 10;
            cheqorsavings.BorderThickness = 2;
            cheqorsavings.CustomizableEdges = customizableEdges7;
            cheqorsavings.DrawMode = DrawMode.OwnerDrawFixed;
            cheqorsavings.DropDownStyle = ComboBoxStyle.DropDownList;
            cheqorsavings.FocusedColor = Color.FromArgb(94, 148, 255);
            cheqorsavings.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cheqorsavings.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            cheqorsavings.ForeColor = Color.Teal;
            cheqorsavings.ItemHeight = 30;
            cheqorsavings.Items.AddRange(new object[] { "Savings", "Cheque" });
            cheqorsavings.Location = new Point(33, 522);
            cheqorsavings.Margin = new Padding(3, 4, 3, 4);
            cheqorsavings.Name = "cheqorsavings";
            cheqorsavings.ShadowDecoration.CustomizableEdges = customizableEdges8;
            cheqorsavings.Size = new Size(322, 36);
            cheqorsavings.TabIndex = 15;
            // 
            // receiptPanel
            // 
            receiptPanel.BackgroundImage = (Image)resources.GetObject("receiptPanel.BackgroundImage");
            receiptPanel.Controls.Add(lblselectedCompany);
            receiptPanel.Controls.Add(guna2HtmlLabel10);
            receiptPanel.Controls.Add(lblAccNum);
            receiptPanel.Controls.Add(guna2HtmlLabel8);
            receiptPanel.Controls.Add(continueBtn);
            receiptPanel.Controls.Add(lblCurrentBal);
            receiptPanel.Controls.Add(lblAmountSubtracted);
            receiptPanel.Controls.Add(lblcheqorsavings);
            receiptPanel.Controls.Add(guna2HtmlLabel7);
            receiptPanel.Controls.Add(guna2HtmlLabel6);
            receiptPanel.Controls.Add(guna2HtmlLabel5);
            receiptPanel.Controls.Add(guna2HtmlLabel4);
            receiptPanel.Controls.Add(guna2HtmlLabel9);
            receiptPanel.CustomizableEdges = customizableEdges11;
            receiptPanel.Location = new Point(15, 192);
            receiptPanel.Margin = new Padding(3, 4, 3, 4);
            receiptPanel.Name = "receiptPanel";
            receiptPanel.ShadowDecoration.CustomizableEdges = customizableEdges12;
            receiptPanel.Size = new Size(368, 452);
            receiptPanel.TabIndex = 17;
            receiptPanel.Paint += receiptPanel_Paint;
            // 
            // lblselectedCompany
            // 
            lblselectedCompany.BackColor = Color.Transparent;
            lblselectedCompany.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblselectedCompany.ForeColor = Color.DarkSlateGray;
            lblselectedCompany.Location = new Point(184, 111);
            lblselectedCompany.Margin = new Padding(3, 4, 3, 4);
            lblselectedCompany.Name = "lblselectedCompany";
            lblselectedCompany.Size = new Size(27, 30);
            lblselectedCompany.TabIndex = 29;
            lblselectedCompany.Text = "---";
            // 
            // guna2HtmlLabel10
            // 
            guna2HtmlLabel10.BackColor = Color.Transparent;
            guna2HtmlLabel10.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel10.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel10.Location = new Point(34, 111);
            guna2HtmlLabel10.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            guna2HtmlLabel10.Size = new Size(143, 30);
            guna2HtmlLabel10.TabIndex = 28;
            guna2HtmlLabel10.Text = "Paid Company:";
            // 
            // lblAccNum
            // 
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(184, 213);
            lblAccNum.Margin = new Padding(3, 4, 3, 4);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(27, 30);
            lblAccNum.TabIndex = 27;
            lblAccNum.Text = "---";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel8.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel8.Location = new Point(75, 161);
            guna2HtmlLabel8.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(101, 30);
            guna2HtmlLabel8.TabIndex = 26;
            guna2HtmlLabel8.Text = "Paid With:";
            // 
            // continueBtn
            // 
            continueBtn.BackColor = Color.Transparent;
            continueBtn.BorderColor = Color.DarkSlateGray;
            continueBtn.BorderRadius = 15;
            continueBtn.BorderThickness = 2;
            continueBtn.CustomizableEdges = customizableEdges9;
            continueBtn.DisabledState.BorderColor = Color.DarkGray;
            continueBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            continueBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            continueBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            continueBtn.FillColor = Color.Teal;
            continueBtn.Font = new Font("Segoe UI Emoji", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            continueBtn.ForeColor = Color.White;
            continueBtn.Location = new Point(33, 392);
            continueBtn.Margin = new Padding(3, 4, 3, 4);
            continueBtn.Name = "continueBtn";
            continueBtn.ShadowDecoration.CustomizableEdges = customizableEdges10;
            continueBtn.Size = new Size(305, 56);
            continueBtn.TabIndex = 17;
            continueBtn.Text = "Continue to merchant";
            continueBtn.Click += continueBtn_Click;
            // 
            // lblCurrentBal
            // 
            lblCurrentBal.BackColor = Color.Transparent;
            lblCurrentBal.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentBal.ForeColor = Color.DarkSlateGray;
            lblCurrentBal.Location = new Point(184, 331);
            lblCurrentBal.Margin = new Padding(3, 4, 3, 4);
            lblCurrentBal.Name = "lblCurrentBal";
            lblCurrentBal.Size = new Size(27, 30);
            lblCurrentBal.TabIndex = 25;
            lblCurrentBal.Text = "---";
            // 
            // lblAmountSubtracted
            // 
            lblAmountSubtracted.BackColor = Color.Transparent;
            lblAmountSubtracted.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAmountSubtracted.ForeColor = Color.DarkSlateGray;
            lblAmountSubtracted.Location = new Point(184, 273);
            lblAmountSubtracted.Margin = new Padding(3, 4, 3, 4);
            lblAmountSubtracted.Name = "lblAmountSubtracted";
            lblAmountSubtracted.Size = new Size(27, 30);
            lblAmountSubtracted.TabIndex = 24;
            lblAmountSubtracted.Text = "---";
            // 
            // lblcheqorsavings
            // 
            lblcheqorsavings.BackColor = Color.Transparent;
            lblcheqorsavings.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcheqorsavings.ForeColor = Color.DarkSlateGray;
            lblcheqorsavings.Location = new Point(184, 161);
            lblcheqorsavings.Margin = new Padding(3, 4, 3, 4);
            lblcheqorsavings.Name = "lblcheqorsavings";
            lblcheqorsavings.Size = new Size(27, 30);
            lblcheqorsavings.TabIndex = 23;
            lblcheqorsavings.Text = "---";
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel7.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel7.Location = new Point(4, 73);
            guna2HtmlLabel7.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(355, 30);
            guna2HtmlLabel7.TabIndex = 22;
            guna2HtmlLabel7.Text = "--------------------------------------------";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel6.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel6.Location = new Point(23, 331);
            guna2HtmlLabel6.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(159, 30);
            guna2HtmlLabel6.TabIndex = 21;
            guna2HtmlLabel6.Text = "Current Balance:";
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel5.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel5.Location = new Point(3, 273);
            guna2HtmlLabel5.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(178, 30);
            guna2HtmlLabel5.TabIndex = 20;
            guna2HtmlLabel5.Text = "Amount deducted:";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel4.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel4.Location = new Point(13, 213);
            guna2HtmlLabel4.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(169, 30);
            guna2HtmlLabel4.TabIndex = 19;
            guna2HtmlLabel4.Text = "Account Number:";
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel9.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel9.Location = new Point(42, 5);
            guna2HtmlLabel9.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(281, 43);
            guna2HtmlLabel9.TabIndex = 18;
            guna2HtmlLabel9.Text = "Transaction Receipt";
            // 
            // exitBtn
            // 
            exitBtn.CustomizableEdges = customizableEdges13;
            exitBtn.DisabledState.BorderColor = Color.DarkGray;
            exitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            exitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            exitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            exitBtn.FillColor = Color.FromArgb(192, 0, 0);
            exitBtn.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitBtn.ForeColor = Color.White;
            exitBtn.Location = new Point(362, 3);
            exitBtn.Margin = new Padding(3, 4, 3, 4);
            exitBtn.Name = "exitBtn";
            exitBtn.ShadowDecoration.CustomizableEdges = customizableEdges14;
            exitBtn.Size = new Size(34, 37);
            exitBtn.TabIndex = 18;
            exitBtn.Text = "X";
            exitBtn.Click += exitBtn_Click;
            // 
            // ElectricBillSec
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(400, 682);
            Controls.Add(exitBtn);
            Controls.Add(receiptPanel);
            Controls.Add(guna2HtmlLabel3);
            Controls.Add(cheqorsavings);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(electricChoice);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(PayBtn);
            Controls.Add(txtPayamount);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "ElectricBillSec";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ElectricBillSec";
            Load += ElectricBillSec_Load;
            receiptPanel.ResumeLayout(false);
            receiptPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2ComboBox electricChoice;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button PayBtn;
        private Guna.UI2.WinForms.Guna2TextBox txtPayamount;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2ComboBox cheqorsavings;
        private Guna.UI2.WinForms.Guna2Panel receiptPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAccNum;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2Button continueBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblCurrentBal;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAmountSubtracted;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblcheqorsavings;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblselectedCompany;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
    }
}
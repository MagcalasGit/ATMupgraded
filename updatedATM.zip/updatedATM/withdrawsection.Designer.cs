﻿namespace updatedATM
{
    partial class withdrawsection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(withdrawsection));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cbxsaviOrCheq = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            withdrawBtn = new Guna.UI2.WinForms.Guna2Button();
            txtWithdrawAmount = new Guna.UI2.WinForms.Guna2TextBox();
            receiptPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblAccNum = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            continueBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBal = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAmountAdd = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAccountNum = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            exitBtn = new Guna.UI2.WinForms.Guna2Button();
            receiptPanel.SuspendLayout();
            SuspendLayout();
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel2.Location = new Point(57, 460);
            guna2HtmlLabel2.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(290, 30);
            guna2HtmlLabel2.TabIndex = 9;
            guna2HtmlLabel2.Text = "Choose where to deposit here:";
            // 
            // cbxsaviOrCheq
            // 
            cbxsaviOrCheq.AutoCompleteCustomSource.AddRange(new string[] { "Savings", "Cheque" });
            cbxsaviOrCheq.BackColor = Color.Transparent;
            cbxsaviOrCheq.BorderColor = Color.DarkSlateGray;
            cbxsaviOrCheq.BorderRadius = 10;
            cbxsaviOrCheq.BorderThickness = 2;
            cbxsaviOrCheq.CustomizableEdges = customizableEdges1;
            cbxsaviOrCheq.DrawMode = DrawMode.OwnerDrawFixed;
            cbxsaviOrCheq.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxsaviOrCheq.FocusedColor = Color.FromArgb(94, 148, 255);
            cbxsaviOrCheq.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbxsaviOrCheq.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            cbxsaviOrCheq.ForeColor = Color.Teal;
            cbxsaviOrCheq.ItemHeight = 30;
            cbxsaviOrCheq.Items.AddRange(new object[] { "Savings", "Cheque" });
            cbxsaviOrCheq.Location = new Point(43, 492);
            cbxsaviOrCheq.Margin = new Padding(3, 4, 3, 4);
            cbxsaviOrCheq.Name = "cbxsaviOrCheq";
            cbxsaviOrCheq.ShadowDecoration.CustomizableEdges = customizableEdges2;
            cbxsaviOrCheq.Size = new Size(322, 36);
            cbxsaviOrCheq.TabIndex = 8;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Location = new Point(57, 327);
            guna2HtmlLabel1.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(191, 30);
            guna2HtmlLabel1.TabIndex = 7;
            guna2HtmlLabel1.Text = "Enter Amount Here:";
            // 
            // withdrawBtn
            // 
            withdrawBtn.BackColor = Color.Transparent;
            withdrawBtn.BorderColor = Color.DarkSlateGray;
            withdrawBtn.BorderRadius = 15;
            withdrawBtn.BorderThickness = 2;
            withdrawBtn.CustomizableEdges = customizableEdges3;
            withdrawBtn.DisabledState.BorderColor = Color.DarkGray;
            withdrawBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            withdrawBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            withdrawBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            withdrawBtn.FillColor = Color.Teal;
            withdrawBtn.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            withdrawBtn.ForeColor = Color.White;
            withdrawBtn.Location = new Point(83, 588);
            withdrawBtn.Margin = new Padding(3, 4, 3, 4);
            withdrawBtn.Name = "withdrawBtn";
            withdrawBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            withdrawBtn.Size = new Size(241, 60);
            withdrawBtn.TabIndex = 6;
            withdrawBtn.Text = "Withdraw";
            withdrawBtn.Click += withdrawBtn_Click;
            // 
            // txtWithdrawAmount
            // 
            txtWithdrawAmount.BackColor = Color.Transparent;
            txtWithdrawAmount.BorderColor = Color.DarkSlateGray;
            txtWithdrawAmount.BorderRadius = 10;
            txtWithdrawAmount.BorderThickness = 2;
            txtWithdrawAmount.CustomizableEdges = customizableEdges5;
            txtWithdrawAmount.DefaultText = "";
            txtWithdrawAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtWithdrawAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtWithdrawAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtWithdrawAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtWithdrawAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtWithdrawAmount.Font = new Font("Segoe UI", 9F);
            txtWithdrawAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtWithdrawAmount.Location = new Point(43, 358);
            txtWithdrawAmount.Margin = new Padding(3, 5, 3, 5);
            txtWithdrawAmount.Name = "txtWithdrawAmount";
            txtWithdrawAmount.PasswordChar = '\0';
            txtWithdrawAmount.PlaceholderText = "";
            txtWithdrawAmount.SelectedText = "";
            txtWithdrawAmount.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtWithdrawAmount.Size = new Size(322, 80);
            txtWithdrawAmount.TabIndex = 5;
            // 
            // receiptPanel
            // 
            receiptPanel.BackColor = Color.Transparent;
            receiptPanel.BackgroundImage = (Image)resources.GetObject("receiptPanel.BackgroundImage");
            receiptPanel.BackgroundImageLayout = ImageLayout.Stretch;
            receiptPanel.BorderColor = Color.DarkSlateGray;
            receiptPanel.BorderRadius = 10;
            receiptPanel.BorderThickness = 2;
            receiptPanel.Controls.Add(lblAccNum);
            receiptPanel.Controls.Add(guna2HtmlLabel8);
            receiptPanel.Controls.Add(continueBtn);
            receiptPanel.Controls.Add(lblCurrentBal);
            receiptPanel.Controls.Add(lblAmountAdd);
            receiptPanel.Controls.Add(lblAccountNum);
            receiptPanel.Controls.Add(guna2HtmlLabel7);
            receiptPanel.Controls.Add(guna2HtmlLabel6);
            receiptPanel.Controls.Add(guna2HtmlLabel5);
            receiptPanel.Controls.Add(guna2HtmlLabel4);
            receiptPanel.Controls.Add(guna2HtmlLabel3);
            receiptPanel.CustomizableEdges = customizableEdges9;
            receiptPanel.FillColor = Color.Transparent;
            receiptPanel.Location = new Point(20, 170);
            receiptPanel.Margin = new Padding(3, 4, 3, 4);
            receiptPanel.Name = "receiptPanel";
            receiptPanel.ShadowDecoration.CustomizableEdges = customizableEdges10;
            receiptPanel.Size = new Size(359, 517);
            receiptPanel.TabIndex = 10;
            // 
            // lblAccNum
            // 
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(185, 213);
            lblAccNum.Margin = new Padding(3, 4, 3, 4);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(27, 30);
            lblAccNum.TabIndex = 16;
            lblAccNum.Text = "---";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel8.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel8.Location = new Point(56, 156);
            guna2HtmlLabel8.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(125, 30);
            guna2HtmlLabel8.TabIndex = 15;
            guna2HtmlLabel8.Text = "Withdraw in:";
            // 
            // continueBtn
            // 
            continueBtn.BackColor = Color.Transparent;
            continueBtn.BorderColor = Color.DarkSlateGray;
            continueBtn.BorderRadius = 15;
            continueBtn.BorderThickness = 2;
            continueBtn.CustomizableEdges = customizableEdges7;
            continueBtn.DisabledState.BorderColor = Color.DarkGray;
            continueBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            continueBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            continueBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            continueBtn.FillColor = Color.Teal;
            continueBtn.Font = new Font("Segoe UI Emoji", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            continueBtn.ForeColor = Color.White;
            continueBtn.Location = new Point(25, 429);
            continueBtn.Margin = new Padding(3, 4, 3, 4);
            continueBtn.Name = "continueBtn";
            continueBtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            continueBtn.Size = new Size(305, 56);
            continueBtn.TabIndex = 7;
            continueBtn.Text = "Continue to merchant";
            continueBtn.Click += continueBtn_Click;
            // 
            // lblCurrentBal
            // 
            lblCurrentBal.BackColor = Color.Transparent;
            lblCurrentBal.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentBal.ForeColor = Color.DarkSlateGray;
            lblCurrentBal.Location = new Point(185, 331);
            lblCurrentBal.Margin = new Padding(3, 4, 3, 4);
            lblCurrentBal.Name = "lblCurrentBal";
            lblCurrentBal.Size = new Size(27, 30);
            lblCurrentBal.TabIndex = 14;
            lblCurrentBal.Text = "---";
            // 
            // lblAmountAdd
            // 
            lblAmountAdd.BackColor = Color.Transparent;
            lblAmountAdd.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAmountAdd.ForeColor = Color.DarkSlateGray;
            lblAmountAdd.Location = new Point(185, 273);
            lblAmountAdd.Margin = new Padding(3, 4, 3, 4);
            lblAmountAdd.Name = "lblAmountAdd";
            lblAmountAdd.Size = new Size(27, 30);
            lblAmountAdd.TabIndex = 13;
            lblAmountAdd.Text = "---";
            // 
            // lblAccountNum
            // 
            lblAccountNum.BackColor = Color.Transparent;
            lblAccountNum.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccountNum.ForeColor = Color.DarkSlateGray;
            lblAccountNum.Location = new Point(185, 156);
            lblAccountNum.Margin = new Padding(3, 4, 3, 4);
            lblAccountNum.Name = "lblAccountNum";
            lblAccountNum.Size = new Size(27, 30);
            lblAccountNum.TabIndex = 12;
            lblAccountNum.Text = "---";
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel7.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel7.Location = new Point(1, 92);
            guna2HtmlLabel7.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(355, 30);
            guna2HtmlLabel7.TabIndex = 11;
            guna2HtmlLabel7.Text = "--------------------------------------------";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel6.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel6.Location = new Point(25, 331);
            guna2HtmlLabel6.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(159, 30);
            guna2HtmlLabel6.TabIndex = 10;
            guna2HtmlLabel6.Text = "Current Balance:";
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel5.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel5.Location = new Point(6, 273);
            guna2HtmlLabel5.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(178, 30);
            guna2HtmlLabel5.TabIndex = 9;
            guna2HtmlLabel5.Text = "Amount deducted:";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel4.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel4.Location = new Point(15, 213);
            guna2HtmlLabel4.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(169, 30);
            guna2HtmlLabel4.TabIndex = 8;
            guna2HtmlLabel4.Text = "Account Number:";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel3.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel3.Location = new Point(45, 23);
            guna2HtmlLabel3.Margin = new Padding(3, 4, 3, 4);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(281, 43);
            guna2HtmlLabel3.TabIndex = 7;
            guna2HtmlLabel3.Text = "Transaction Receipt";
            // 
            // exitBtn
            // 
            exitBtn.CustomizableEdges = customizableEdges11;
            exitBtn.DisabledState.BorderColor = Color.DarkGray;
            exitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            exitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            exitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            exitBtn.FillColor = Color.FromArgb(192, 0, 0);
            exitBtn.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitBtn.ForeColor = Color.White;
            exitBtn.Location = new Point(363, 3);
            exitBtn.Margin = new Padding(3, 4, 3, 4);
            exitBtn.Name = "exitBtn";
            exitBtn.ShadowDecoration.CustomizableEdges = customizableEdges12;
            exitBtn.Size = new Size(34, 37);
            exitBtn.TabIndex = 11;
            exitBtn.Text = "X";
            exitBtn.Click += exitBtn_Click;
            // 
            // withdrawsection
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(400, 700);
            Controls.Add(exitBtn);
            Controls.Add(receiptPanel);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(cbxsaviOrCheq);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(withdrawBtn);
            Controls.Add(txtWithdrawAmount);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "withdrawsection";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "withdrawsection";
            Load += withdrawsection_Load;
            receiptPanel.ResumeLayout(false);
            receiptPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2ComboBox cbxsaviOrCheq;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button withdrawBtn;
        private Guna.UI2.WinForms.Guna2TextBox txtWithdrawAmount;
        private Guna.UI2.WinForms.Guna2Panel receiptPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAccNum;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2Button continueBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblCurrentBal;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAmountAdd;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAccountNum;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
    }
}
﻿namespace updatedATM
{
    partial class depositsection
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(depositsection));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtDepositAmount = new Guna.UI2.WinForms.Guna2TextBox();
            depositBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cbxsaviOrCheq = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            receiptPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblAccNum = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            continueBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBal = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAmountAdd = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAccountNum = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            exitBtn = new Guna.UI2.WinForms.Guna2Button();
            receiptPanel.SuspendLayout();
            SuspendLayout();
            // 
            // txtDepositAmount
            // 
            txtDepositAmount.BackColor = Color.Transparent;
            txtDepositAmount.BorderColor = Color.DarkSlateGray;
            txtDepositAmount.BorderRadius = 10;
            txtDepositAmount.BorderThickness = 2;
            txtDepositAmount.CustomizableEdges = customizableEdges1;
            txtDepositAmount.DefaultText = "";
            txtDepositAmount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDepositAmount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDepositAmount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDepositAmount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDepositAmount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDepositAmount.Font = new Font("Segoe UI", 9F);
            txtDepositAmount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDepositAmount.Location = new Point(53, 323);
            txtDepositAmount.Name = "txtDepositAmount";
            txtDepositAmount.PasswordChar = '\0';
            txtDepositAmount.PlaceholderText = "";
            txtDepositAmount.SelectedText = "";
            txtDepositAmount.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtDepositAmount.Size = new Size(282, 60);
            txtDepositAmount.TabIndex = 0;
            txtDepositAmount.TextChanged += txtDepositAmount_TextChanged;
            // 
            // depositBtn
            // 
            depositBtn.BackColor = Color.Transparent;
            depositBtn.BorderColor = Color.DarkSlateGray;
            depositBtn.BorderRadius = 15;
            depositBtn.BorderThickness = 2;
            depositBtn.CustomizableEdges = customizableEdges3;
            depositBtn.DisabledState.BorderColor = Color.DarkGray;
            depositBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            depositBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            depositBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            depositBtn.FillColor = Color.Teal;
            depositBtn.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            depositBtn.ForeColor = Color.White;
            depositBtn.Location = new Point(88, 496);
            depositBtn.Name = "depositBtn";
            depositBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            depositBtn.Size = new Size(211, 45);
            depositBtn.TabIndex = 1;
            depositBtn.Text = "Deposit ";
            depositBtn.Click += depositBtn_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Location = new Point(66, 300);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(153, 23);
            guna2HtmlLabel1.TabIndex = 2;
            guna2HtmlLabel1.Text = "Enter Amount Here:";
            // 
            // cbxsaviOrCheq
            // 
            cbxsaviOrCheq.AutoCompleteCustomSource.AddRange(new string[] { "Savings", "Cheque" });
            cbxsaviOrCheq.BackColor = Color.Transparent;
            cbxsaviOrCheq.BorderColor = Color.DarkSlateGray;
            cbxsaviOrCheq.BorderRadius = 10;
            cbxsaviOrCheq.BorderThickness = 2;
            cbxsaviOrCheq.CustomizableEdges = customizableEdges5;
            cbxsaviOrCheq.DrawMode = DrawMode.OwnerDrawFixed;
            cbxsaviOrCheq.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxsaviOrCheq.FocusedColor = Color.FromArgb(94, 148, 255);
            cbxsaviOrCheq.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbxsaviOrCheq.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            cbxsaviOrCheq.ForeColor = Color.Teal;
            cbxsaviOrCheq.ItemHeight = 30;
            cbxsaviOrCheq.Items.AddRange(new object[] { "Savings", "Cheque" });
            cbxsaviOrCheq.Location = new Point(53, 424);
            cbxsaviOrCheq.Name = "cbxsaviOrCheq";
            cbxsaviOrCheq.ShadowDecoration.CustomizableEdges = customizableEdges6;
            cbxsaviOrCheq.Size = new Size(282, 36);
            cbxsaviOrCheq.TabIndex = 3;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel2.Location = new Point(66, 401);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(233, 23);
            guna2HtmlLabel2.TabIndex = 5;
            guna2HtmlLabel2.Text = "Choose where to deposit here:";
            // 
            // receiptPanel
            // 
            receiptPanel.BackColor = Color.Transparent;
            receiptPanel.BackgroundImage = (Image)resources.GetObject("receiptPanel.BackgroundImage");
            receiptPanel.BackgroundImageLayout = ImageLayout.Stretch;
            receiptPanel.BorderColor = Color.DarkSlateGray;
            receiptPanel.BorderRadius = 10;
            receiptPanel.BorderThickness = 2;
            receiptPanel.Controls.Add(lblAccNum);
            receiptPanel.Controls.Add(guna2HtmlLabel8);
            receiptPanel.Controls.Add(continueBtn);
            receiptPanel.Controls.Add(lblCurrentBal);
            receiptPanel.Controls.Add(lblAmountAdd);
            receiptPanel.Controls.Add(lblAccountNum);
            receiptPanel.Controls.Add(guna2HtmlLabel7);
            receiptPanel.Controls.Add(guna2HtmlLabel6);
            receiptPanel.Controls.Add(guna2HtmlLabel5);
            receiptPanel.Controls.Add(guna2HtmlLabel4);
            receiptPanel.Controls.Add(guna2HtmlLabel3);
            receiptPanel.CustomizableEdges = customizableEdges9;
            receiptPanel.FillColor = Color.Transparent;
            receiptPanel.Location = new Point(38, 164);
            receiptPanel.Name = "receiptPanel";
            receiptPanel.ShadowDecoration.CustomizableEdges = customizableEdges10;
            receiptPanel.Size = new Size(314, 388);
            receiptPanel.TabIndex = 6;
            receiptPanel.Paint += receiptPanel_Paint;
            // 
            // lblAccNum
            // 
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(151, 160);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(21, 23);
            lblAccNum.TabIndex = 16;
            lblAccNum.Text = "---";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel8.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel8.Location = new Point(65, 117);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(85, 23);
            guna2HtmlLabel8.TabIndex = 15;
            guna2HtmlLabel8.Text = "Deposit in:";
            // 
            // continueBtn
            // 
            continueBtn.BackColor = Color.Transparent;
            continueBtn.BorderColor = Color.DarkSlateGray;
            continueBtn.BorderRadius = 15;
            continueBtn.BorderThickness = 2;
            continueBtn.CustomizableEdges = customizableEdges7;
            continueBtn.DisabledState.BorderColor = Color.DarkGray;
            continueBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            continueBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            continueBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            continueBtn.FillColor = Color.Teal;
            continueBtn.Font = new Font("Segoe UI Emoji", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            continueBtn.ForeColor = Color.White;
            continueBtn.Location = new Point(22, 322);
            continueBtn.Name = "continueBtn";
            continueBtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            continueBtn.Size = new Size(267, 42);
            continueBtn.TabIndex = 7;
            continueBtn.Text = "Continue to merchant";
            continueBtn.Click += continueBtn_Click;
            // 
            // lblCurrentBal
            // 
            lblCurrentBal.BackColor = Color.Transparent;
            lblCurrentBal.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentBal.ForeColor = Color.DarkSlateGray;
            lblCurrentBal.Location = new Point(151, 248);
            lblCurrentBal.Name = "lblCurrentBal";
            lblCurrentBal.Size = new Size(21, 23);
            lblCurrentBal.TabIndex = 14;
            lblCurrentBal.Text = "---";
            // 
            // lblAmountAdd
            // 
            lblAmountAdd.BackColor = Color.Transparent;
            lblAmountAdd.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAmountAdd.ForeColor = Color.DarkSlateGray;
            lblAmountAdd.Location = new Point(151, 205);
            lblAmountAdd.Name = "lblAmountAdd";
            lblAmountAdd.Size = new Size(21, 23);
            lblAmountAdd.TabIndex = 13;
            lblAmountAdd.Text = "---";
            // 
            // lblAccountNum
            // 
            lblAccountNum.BackColor = Color.Transparent;
            lblAccountNum.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccountNum.ForeColor = Color.DarkSlateGray;
            lblAccountNum.Location = new Point(151, 117);
            lblAccountNum.Name = "lblAccountNum";
            lblAccountNum.Size = new Size(21, 23);
            lblAccountNum.TabIndex = 12;
            lblAccountNum.Text = "---";
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel7.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel7.Location = new Point(22, 67);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(267, 23);
            guna2HtmlLabel7.TabIndex = 11;
            guna2HtmlLabel7.Text = "--------------------------------------------";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel6.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel6.Location = new Point(22, 248);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(128, 23);
            guna2HtmlLabel6.TabIndex = 10;
            guna2HtmlLabel6.Text = "Current Balance:";
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel5.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel5.Location = new Point(29, 205);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(121, 23);
            guna2HtmlLabel5.TabIndex = 9;
            guna2HtmlLabel5.Text = "Amount added:";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel4.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel4.Location = new Point(13, 160);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(137, 23);
            guna2HtmlLabel4.TabIndex = 8;
            guna2HtmlLabel4.Text = "Account Number:";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel3.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel3.Location = new Point(39, 17);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(229, 34);
            guna2HtmlLabel3.TabIndex = 7;
            guna2HtmlLabel3.Text = "Transaction Receipt";
            // 
            // exitBtn
            // 
            exitBtn.CustomizableEdges = customizableEdges11;
            exitBtn.DisabledState.BorderColor = Color.DarkGray;
            exitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            exitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            exitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            exitBtn.FillColor = Color.FromArgb(192, 0, 0);
            exitBtn.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitBtn.ForeColor = Color.White;
            exitBtn.Location = new Point(358, 3);
            exitBtn.Name = "exitBtn";
            exitBtn.ShadowDecoration.CustomizableEdges = customizableEdges12;
            exitBtn.Size = new Size(30, 28);
            exitBtn.TabIndex = 7;
            exitBtn.Text = "X";
            exitBtn.Click += exitBtn_Click;
            // 
            // depositsection
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(391, 609);
            Controls.Add(exitBtn);
            Controls.Add(receiptPanel);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(cbxsaviOrCheq);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(depositBtn);
            Controls.Add(txtDepositAmount);
            FormBorderStyle = FormBorderStyle.None;
            Name = "depositsection";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "depositsection";
            receiptPanel.ResumeLayout(false);
            receiptPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtDepositAmount;
        private Guna.UI2.WinForms.Guna2Button depositBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2ComboBox cbxsaviOrCheq;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2Panel receiptPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblCurrentBal;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAmountAdd;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAccountNum;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2Button continueBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAccNum;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
    }
}
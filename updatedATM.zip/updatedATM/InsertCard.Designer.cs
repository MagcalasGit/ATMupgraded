﻿namespace updatedATM
{
    partial class InsertCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InsertCard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            PnlInsertCard = new Guna.UI2.WinForms.Guna2Panel();
            deleteBtn = new Guna.UI2.WinForms.Guna2Button();
            clearBtn = new Guna.UI2.WinForms.Guna2Button();
            zeroBtn = new Guna.UI2.WinForms.Guna2Button();
            threeBtn = new Guna.UI2.WinForms.Guna2Button();
            twoBtn = new Guna.UI2.WinForms.Guna2Button();
            oneBtn = new Guna.UI2.WinForms.Guna2Button();
            sixBtn = new Guna.UI2.WinForms.Guna2Button();
            fiveBtn = new Guna.UI2.WinForms.Guna2Button();
            fourBtn = new Guna.UI2.WinForms.Guna2Button();
            nineBtn = new Guna.UI2.WinForms.Guna2Button();
            eightBtn = new Guna.UI2.WinForms.Guna2Button();
            sevenBtn = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            btninsertCard = new Guna.UI2.WinForms.Guna2Button();
            txtInsertCard = new Guna.UI2.WinForms.Guna2TextBox();
            exitBtn = new Guna.UI2.WinForms.Guna2Button();
            PnlInsertCard.SuspendLayout();
            SuspendLayout();
            // 
            // PnlInsertCard
            // 
            PnlInsertCard.BackColor = Color.Teal;
            PnlInsertCard.BackgroundImage = (Image)resources.GetObject("PnlInsertCard.BackgroundImage");
            PnlInsertCard.Controls.Add(deleteBtn);
            PnlInsertCard.Controls.Add(clearBtn);
            PnlInsertCard.Controls.Add(zeroBtn);
            PnlInsertCard.Controls.Add(threeBtn);
            PnlInsertCard.Controls.Add(twoBtn);
            PnlInsertCard.Controls.Add(oneBtn);
            PnlInsertCard.Controls.Add(sixBtn);
            PnlInsertCard.Controls.Add(fiveBtn);
            PnlInsertCard.Controls.Add(fourBtn);
            PnlInsertCard.Controls.Add(nineBtn);
            PnlInsertCard.Controls.Add(eightBtn);
            PnlInsertCard.Controls.Add(sevenBtn);
            PnlInsertCard.Controls.Add(guna2HtmlLabel2);
            PnlInsertCard.Controls.Add(btninsertCard);
            PnlInsertCard.Controls.Add(txtInsertCard);
            PnlInsertCard.CustomizableEdges = customizableEdges29;
            PnlInsertCard.Location = new Point(107, 282);
            PnlInsertCard.Name = "PnlInsertCard";
            PnlInsertCard.ShadowDecoration.CustomizableEdges = customizableEdges30;
            PnlInsertCard.Size = new Size(499, 223);
            PnlInsertCard.TabIndex = 13;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.Transparent;
            deleteBtn.BorderColor = Color.DarkSlateGray;
            deleteBtn.BorderRadius = 10;
            deleteBtn.BorderThickness = 2;
            deleteBtn.CustomizableEdges = customizableEdges1;
            deleteBtn.DisabledState.BorderColor = Color.DarkGray;
            deleteBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            deleteBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            deleteBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            deleteBtn.FillColor = Color.Teal;
            deleteBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            deleteBtn.ForeColor = Color.White;
            deleteBtn.Location = new Point(420, 161);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            deleteBtn.Size = new Size(61, 45);
            deleteBtn.TabIndex = 37;
            deleteBtn.Text = "del";
            deleteBtn.Click += deleteBtn_Click;
            // 
            // clearBtn
            // 
            clearBtn.BackColor = Color.Transparent;
            clearBtn.BorderColor = Color.DarkSlateGray;
            clearBtn.BorderRadius = 10;
            clearBtn.BorderThickness = 2;
            clearBtn.CustomizableEdges = customizableEdges3;
            clearBtn.DisabledState.BorderColor = Color.DarkGray;
            clearBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            clearBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            clearBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            clearBtn.FillColor = Color.Teal;
            clearBtn.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            clearBtn.ForeColor = Color.White;
            clearBtn.Location = new Point(286, 161);
            clearBtn.Name = "clearBtn";
            clearBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            clearBtn.Size = new Size(61, 45);
            clearBtn.TabIndex = 36;
            clearBtn.Text = "clear";
            clearBtn.Click += clearBtn_Click;
            // 
            // zeroBtn
            // 
            zeroBtn.BackColor = Color.Transparent;
            zeroBtn.BorderColor = Color.DarkSlateGray;
            zeroBtn.BorderRadius = 10;
            zeroBtn.BorderThickness = 2;
            zeroBtn.CustomizableEdges = customizableEdges5;
            zeroBtn.DisabledState.BorderColor = Color.DarkGray;
            zeroBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            zeroBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            zeroBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            zeroBtn.FillColor = Color.Teal;
            zeroBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            zeroBtn.ForeColor = Color.White;
            zeroBtn.Location = new Point(353, 160);
            zeroBtn.Name = "zeroBtn";
            zeroBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            zeroBtn.Size = new Size(61, 45);
            zeroBtn.TabIndex = 35;
            zeroBtn.Text = "0";
            zeroBtn.Click += zeroBtn_Click;
            // 
            // threeBtn
            // 
            threeBtn.BackColor = Color.Transparent;
            threeBtn.BorderColor = Color.DarkSlateGray;
            threeBtn.BorderRadius = 10;
            threeBtn.BorderThickness = 2;
            threeBtn.CustomizableEdges = customizableEdges7;
            threeBtn.DisabledState.BorderColor = Color.DarkGray;
            threeBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            threeBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            threeBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            threeBtn.FillColor = Color.Teal;
            threeBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            threeBtn.ForeColor = Color.White;
            threeBtn.Location = new Point(420, 110);
            threeBtn.Name = "threeBtn";
            threeBtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            threeBtn.Size = new Size(61, 45);
            threeBtn.TabIndex = 34;
            threeBtn.Text = "3";
            threeBtn.Click += threeBtn_Click;
            // 
            // twoBtn
            // 
            twoBtn.BackColor = Color.Transparent;
            twoBtn.BorderColor = Color.DarkSlateGray;
            twoBtn.BorderRadius = 10;
            twoBtn.BorderThickness = 2;
            twoBtn.CustomizableEdges = customizableEdges9;
            twoBtn.DisabledState.BorderColor = Color.DarkGray;
            twoBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            twoBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            twoBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            twoBtn.FillColor = Color.Teal;
            twoBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            twoBtn.ForeColor = Color.White;
            twoBtn.Location = new Point(353, 110);
            twoBtn.Name = "twoBtn";
            twoBtn.ShadowDecoration.CustomizableEdges = customizableEdges10;
            twoBtn.Size = new Size(61, 45);
            twoBtn.TabIndex = 33;
            twoBtn.Text = "2";
            twoBtn.Click += twoBtn_Click;
            // 
            // oneBtn
            // 
            oneBtn.BackColor = Color.Transparent;
            oneBtn.BorderColor = Color.DarkSlateGray;
            oneBtn.BorderRadius = 10;
            oneBtn.BorderThickness = 2;
            oneBtn.CustomizableEdges = customizableEdges11;
            oneBtn.DisabledState.BorderColor = Color.DarkGray;
            oneBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            oneBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            oneBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            oneBtn.FillColor = Color.Teal;
            oneBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            oneBtn.ForeColor = Color.White;
            oneBtn.Location = new Point(286, 110);
            oneBtn.Name = "oneBtn";
            oneBtn.ShadowDecoration.CustomizableEdges = customizableEdges12;
            oneBtn.Size = new Size(61, 45);
            oneBtn.TabIndex = 32;
            oneBtn.Text = "1";
            oneBtn.Click += oneBtn_Click;
            // 
            // sixBtn
            // 
            sixBtn.BackColor = Color.Transparent;
            sixBtn.BorderColor = Color.DarkSlateGray;
            sixBtn.BorderRadius = 10;
            sixBtn.BorderThickness = 2;
            sixBtn.CustomizableEdges = customizableEdges13;
            sixBtn.DisabledState.BorderColor = Color.DarkGray;
            sixBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            sixBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            sixBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            sixBtn.FillColor = Color.Teal;
            sixBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sixBtn.ForeColor = Color.White;
            sixBtn.Location = new Point(420, 59);
            sixBtn.Name = "sixBtn";
            sixBtn.ShadowDecoration.CustomizableEdges = customizableEdges14;
            sixBtn.Size = new Size(61, 45);
            sixBtn.TabIndex = 31;
            sixBtn.Text = "6";
            sixBtn.Click += sixBtn_Click;
            // 
            // fiveBtn
            // 
            fiveBtn.BackColor = Color.Transparent;
            fiveBtn.BorderColor = Color.DarkSlateGray;
            fiveBtn.BorderRadius = 10;
            fiveBtn.BorderThickness = 2;
            fiveBtn.CustomizableEdges = customizableEdges15;
            fiveBtn.DisabledState.BorderColor = Color.DarkGray;
            fiveBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            fiveBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            fiveBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            fiveBtn.FillColor = Color.Teal;
            fiveBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fiveBtn.ForeColor = Color.White;
            fiveBtn.Location = new Point(353, 59);
            fiveBtn.Name = "fiveBtn";
            fiveBtn.ShadowDecoration.CustomizableEdges = customizableEdges16;
            fiveBtn.Size = new Size(61, 45);
            fiveBtn.TabIndex = 30;
            fiveBtn.Text = "5";
            fiveBtn.Click += fiveBtn_Click;
            // 
            // fourBtn
            // 
            fourBtn.BackColor = Color.Transparent;
            fourBtn.BorderColor = Color.DarkSlateGray;
            fourBtn.BorderRadius = 10;
            fourBtn.BorderThickness = 2;
            fourBtn.CustomizableEdges = customizableEdges17;
            fourBtn.DisabledState.BorderColor = Color.DarkGray;
            fourBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            fourBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            fourBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            fourBtn.FillColor = Color.Teal;
            fourBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fourBtn.ForeColor = Color.White;
            fourBtn.Location = new Point(286, 59);
            fourBtn.Name = "fourBtn";
            fourBtn.ShadowDecoration.CustomizableEdges = customizableEdges18;
            fourBtn.Size = new Size(61, 45);
            fourBtn.TabIndex = 29;
            fourBtn.Text = "4";
            fourBtn.Click += fourBtn_Click;
            // 
            // nineBtn
            // 
            nineBtn.BackColor = Color.Transparent;
            nineBtn.BorderColor = Color.DarkSlateGray;
            nineBtn.BorderRadius = 10;
            nineBtn.BorderThickness = 2;
            nineBtn.CustomizableEdges = customizableEdges19;
            nineBtn.DisabledState.BorderColor = Color.DarkGray;
            nineBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            nineBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            nineBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            nineBtn.FillColor = Color.Teal;
            nineBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nineBtn.ForeColor = Color.White;
            nineBtn.Location = new Point(420, 8);
            nineBtn.Name = "nineBtn";
            nineBtn.ShadowDecoration.CustomizableEdges = customizableEdges20;
            nineBtn.Size = new Size(61, 45);
            nineBtn.TabIndex = 28;
            nineBtn.Text = "9";
            nineBtn.Click += nineBtn_Click;
            // 
            // eightBtn
            // 
            eightBtn.BackColor = Color.Transparent;
            eightBtn.BorderColor = Color.DarkSlateGray;
            eightBtn.BorderRadius = 10;
            eightBtn.BorderThickness = 2;
            eightBtn.CustomizableEdges = customizableEdges21;
            eightBtn.DisabledState.BorderColor = Color.DarkGray;
            eightBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            eightBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            eightBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            eightBtn.FillColor = Color.Teal;
            eightBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            eightBtn.ForeColor = Color.White;
            eightBtn.Location = new Point(353, 8);
            eightBtn.Name = "eightBtn";
            eightBtn.ShadowDecoration.CustomizableEdges = customizableEdges22;
            eightBtn.Size = new Size(61, 45);
            eightBtn.TabIndex = 27;
            eightBtn.Text = "8";
            eightBtn.Click += eightBtn_Click;
            // 
            // sevenBtn
            // 
            sevenBtn.BackColor = Color.Transparent;
            sevenBtn.BorderColor = Color.DarkSlateGray;
            sevenBtn.BorderRadius = 10;
            sevenBtn.BorderThickness = 2;
            sevenBtn.CustomizableEdges = customizableEdges23;
            sevenBtn.DisabledState.BorderColor = Color.DarkGray;
            sevenBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            sevenBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            sevenBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            sevenBtn.FillColor = Color.Teal;
            sevenBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sevenBtn.ForeColor = Color.White;
            sevenBtn.Location = new Point(286, 8);
            sevenBtn.Name = "sevenBtn";
            sevenBtn.ShadowDecoration.CustomizableEdges = customizableEdges24;
            sevenBtn.Size = new Size(61, 45);
            sevenBtn.TabIndex = 26;
            sevenBtn.Text = "7";
            sevenBtn.Click += sevenBtn_Click;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel2.Location = new Point(18, 40);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(181, 22);
            guna2HtmlLabel2.TabIndex = 11;
            guna2HtmlLabel2.Text = "Enter 0000 to insert card:";
            // 
            // btninsertCard
            // 
            btninsertCard.BackColor = Color.Transparent;
            btninsertCard.BorderColor = Color.DarkSlateGray;
            btninsertCard.BorderRadius = 10;
            btninsertCard.BorderThickness = 2;
            btninsertCard.CustomizableEdges = customizableEdges25;
            btninsertCard.DisabledState.BorderColor = Color.DarkGray;
            btninsertCard.DisabledState.CustomBorderColor = Color.DarkGray;
            btninsertCard.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btninsertCard.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btninsertCard.FillColor = Color.Teal;
            btninsertCard.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btninsertCard.ForeColor = Color.SeaShell;
            btninsertCard.Location = new Point(53, 152);
            btninsertCard.Name = "btninsertCard";
            btninsertCard.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btninsertCard.Size = new Size(155, 43);
            btninsertCard.TabIndex = 10;
            btninsertCard.Text = "ENTER";
            btninsertCard.Click += btninsertCard_Click;
            // 
            // txtInsertCard
            // 
            txtInsertCard.BackColor = Color.Transparent;
            txtInsertCard.BorderColor = Color.DarkSlateGray;
            txtInsertCard.BorderRadius = 10;
            txtInsertCard.BorderThickness = 2;
            txtInsertCard.CustomizableEdges = customizableEdges27;
            txtInsertCard.DefaultText = "";
            txtInsertCard.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtInsertCard.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtInsertCard.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtInsertCard.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtInsertCard.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtInsertCard.Font = new Font("Segoe UI", 9F);
            txtInsertCard.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtInsertCard.Location = new Point(8, 62);
            txtInsertCard.Name = "txtInsertCard";
            txtInsertCard.PasswordChar = '\0';
            txtInsertCard.PlaceholderText = "";
            txtInsertCard.SelectedText = "";
            txtInsertCard.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtInsertCard.Size = new Size(244, 42);
            txtInsertCard.TabIndex = 5;
            // 
            // exitBtn
            // 
            exitBtn.BackColor = Color.Transparent;
            exitBtn.BorderColor = Color.DarkSlateGray;
            exitBtn.BorderRadius = 5;
            exitBtn.CustomizableEdges = customizableEdges31;
            exitBtn.DisabledState.BorderColor = Color.DarkGray;
            exitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            exitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            exitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            exitBtn.FillColor = Color.DarkRed;
            exitBtn.Font = new Font("Segoe UI", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            exitBtn.ForeColor = Color.White;
            exitBtn.Location = new Point(665, 3);
            exitBtn.Name = "exitBtn";
            exitBtn.ShadowDecoration.CustomizableEdges = customizableEdges32;
            exitBtn.Size = new Size(30, 26);
            exitBtn.TabIndex = 14;
            exitBtn.Text = "X";
            exitBtn.Click += exitBtn_Click;
            // 
            // InsertCard
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(700, 544);
            Controls.Add(exitBtn);
            Controls.Add(PnlInsertCard);
            FormBorderStyle = FormBorderStyle.None;
            Name = "InsertCard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "InsertCard";
            Load += InsertCard_Load;
            PnlInsertCard.ResumeLayout(false);
            PnlInsertCard.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel PnlInsertCard;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2Button btninsertCard;
        private Guna.UI2.WinForms.Guna2TextBox txtInsertCard;
        private Guna.UI2.WinForms.Guna2Button deleteBtn;
        private Guna.UI2.WinForms.Guna2Button clearBtn;
        private Guna.UI2.WinForms.Guna2Button zeroBtn;
        private Guna.UI2.WinForms.Guna2Button threeBtn;
        private Guna.UI2.WinForms.Guna2Button twoBtn;
        private Guna.UI2.WinForms.Guna2Button oneBtn;
        private Guna.UI2.WinForms.Guna2Button sixBtn;
        private Guna.UI2.WinForms.Guna2Button fiveBtn;
        private Guna.UI2.WinForms.Guna2Button fourBtn;
        private Guna.UI2.WinForms.Guna2Button nineBtn;
        private Guna.UI2.WinForms.Guna2Button eightBtn;
        private Guna.UI2.WinForms.Guna2Button sevenBtn;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
    }
}
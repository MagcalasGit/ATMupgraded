﻿namespace updatedATM
{
    partial class WaterBillSec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WaterBillSec));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            waterChoice = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            PayBtn = new Guna.UI2.WinForms.Guna2Button();
            txtPayamount = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            cheqorsavings = new Guna.UI2.WinForms.Guna2ComboBox();
            receiptPanel = new Guna.UI2.WinForms.Guna2Panel();
            lblselectedCompany = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAccNum = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            continueBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBal = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblAmountSubtracted = new Guna.UI2.WinForms.Guna2HtmlLabel();
            lblcheqorsavings = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            exitBtn = new Guna.UI2.WinForms.Guna2Button();
            receiptPanel.SuspendLayout();
            SuspendLayout();
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel2.Location = new Point(68, 415);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(204, 23);
            guna2HtmlLabel2.TabIndex = 19;
            guna2HtmlLabel2.Text = "Choose where to pay here:";
            // 
            // waterChoice
            // 
            waterChoice.AutoCompleteCustomSource.AddRange(new string[] { "Savings", "Cheque" });
            waterChoice.BackColor = Color.Transparent;
            waterChoice.BorderColor = Color.DarkSlateGray;
            waterChoice.BorderRadius = 10;
            waterChoice.BorderThickness = 2;
            waterChoice.CustomizableEdges = customizableEdges1;
            waterChoice.DrawMode = DrawMode.OwnerDrawFixed;
            waterChoice.DropDownStyle = ComboBoxStyle.DropDownList;
            waterChoice.FocusedColor = Color.FromArgb(94, 148, 255);
            waterChoice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            waterChoice.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            waterChoice.ForeColor = Color.Teal;
            waterChoice.ItemHeight = 30;
            waterChoice.Items.AddRange(new object[] { "AWD", "SFWMD", "CWC" });
            waterChoice.Location = new Point(55, 439);
            waterChoice.Name = "waterChoice";
            waterChoice.ShadowDecoration.CustomizableEdges = customizableEdges2;
            waterChoice.Size = new Size(282, 36);
            waterChoice.TabIndex = 18;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Location = new Point(68, 315);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(153, 23);
            guna2HtmlLabel1.TabIndex = 17;
            guna2HtmlLabel1.Text = "Enter Amount Here:";
            // 
            // PayBtn
            // 
            PayBtn.BackColor = Color.Transparent;
            PayBtn.BorderColor = Color.DarkSlateGray;
            PayBtn.BorderRadius = 15;
            PayBtn.BorderThickness = 2;
            PayBtn.CustomizableEdges = customizableEdges3;
            PayBtn.DisabledState.BorderColor = Color.DarkGray;
            PayBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            PayBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            PayBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            PayBtn.FillColor = Color.Teal;
            PayBtn.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PayBtn.ForeColor = Color.White;
            PayBtn.Location = new Point(93, 593);
            PayBtn.Name = "PayBtn";
            PayBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            PayBtn.Size = new Size(211, 45);
            PayBtn.TabIndex = 16;
            PayBtn.Text = "Pay";
            PayBtn.Click += PayBtn_Click;
            // 
            // txtPayamount
            // 
            txtPayamount.BackColor = Color.Transparent;
            txtPayamount.BorderColor = Color.DarkSlateGray;
            txtPayamount.BorderRadius = 10;
            txtPayamount.BorderThickness = 2;
            txtPayamount.CustomizableEdges = customizableEdges5;
            txtPayamount.DefaultText = "";
            txtPayamount.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPayamount.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPayamount.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPayamount.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPayamount.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPayamount.Font = new Font("Segoe UI", 9F);
            txtPayamount.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPayamount.Location = new Point(55, 338);
            txtPayamount.Name = "txtPayamount";
            txtPayamount.PasswordChar = '\0';
            txtPayamount.PlaceholderText = "";
            txtPayamount.SelectedText = "";
            txtPayamount.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtPayamount.Size = new Size(282, 60);
            txtPayamount.TabIndex = 15;
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel3.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel3.Location = new Point(68, 484);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(249, 23);
            guna2HtmlLabel3.TabIndex = 21;
            guna2HtmlLabel3.Text = "Choose which account to pay in:";
            // 
            // cheqorsavings
            // 
            cheqorsavings.AutoCompleteCustomSource.AddRange(new string[] { "Savings", "Cheque" });
            cheqorsavings.BackColor = Color.Transparent;
            cheqorsavings.BorderColor = Color.DarkSlateGray;
            cheqorsavings.BorderRadius = 10;
            cheqorsavings.BorderThickness = 2;
            cheqorsavings.CustomizableEdges = customizableEdges7;
            cheqorsavings.DrawMode = DrawMode.OwnerDrawFixed;
            cheqorsavings.DropDownStyle = ComboBoxStyle.DropDownList;
            cheqorsavings.FocusedColor = Color.FromArgb(94, 148, 255);
            cheqorsavings.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cheqorsavings.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            cheqorsavings.ForeColor = Color.Teal;
            cheqorsavings.ItemHeight = 30;
            cheqorsavings.Items.AddRange(new object[] { "Savings", "Cheque" });
            cheqorsavings.Location = new Point(55, 508);
            cheqorsavings.Name = "cheqorsavings";
            cheqorsavings.ShadowDecoration.CustomizableEdges = customizableEdges8;
            cheqorsavings.Size = new Size(282, 36);
            cheqorsavings.TabIndex = 20;
            // 
            // receiptPanel
            // 
            receiptPanel.BackgroundImage = (Image)resources.GetObject("receiptPanel.BackgroundImage");
            receiptPanel.Controls.Add(lblselectedCompany);
            receiptPanel.Controls.Add(guna2HtmlLabel10);
            receiptPanel.Controls.Add(lblAccNum);
            receiptPanel.Controls.Add(guna2HtmlLabel8);
            receiptPanel.Controls.Add(continueBtn);
            receiptPanel.Controls.Add(lblCurrentBal);
            receiptPanel.Controls.Add(lblAmountSubtracted);
            receiptPanel.Controls.Add(lblcheqorsavings);
            receiptPanel.Controls.Add(guna2HtmlLabel7);
            receiptPanel.Controls.Add(guna2HtmlLabel6);
            receiptPanel.Controls.Add(guna2HtmlLabel5);
            receiptPanel.Controls.Add(guna2HtmlLabel4);
            receiptPanel.Controls.Add(guna2HtmlLabel9);
            receiptPanel.CustomizableEdges = customizableEdges11;
            receiptPanel.Location = new Point(38, 309);
            receiptPanel.Name = "receiptPanel";
            receiptPanel.ShadowDecoration.CustomizableEdges = customizableEdges12;
            receiptPanel.Size = new Size(322, 339);
            receiptPanel.TabIndex = 22;
            receiptPanel.Paint += receiptPanel_Paint;
            // 
            // lblselectedCompany
            // 
            lblselectedCompany.BackColor = Color.Transparent;
            lblselectedCompany.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblselectedCompany.ForeColor = Color.DarkSlateGray;
            lblselectedCompany.Location = new Point(149, 83);
            lblselectedCompany.Name = "lblselectedCompany";
            lblselectedCompany.Size = new Size(21, 23);
            lblselectedCompany.TabIndex = 29;
            lblselectedCompany.Text = "---";
            // 
            // guna2HtmlLabel10
            // 
            guna2HtmlLabel10.BackColor = Color.Transparent;
            guna2HtmlLabel10.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel10.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel10.Location = new Point(30, 83);
            guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            guna2HtmlLabel10.Size = new Size(118, 23);
            guna2HtmlLabel10.TabIndex = 28;
            guna2HtmlLabel10.Text = "Paid Company:";
            // 
            // lblAccNum
            // 
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(149, 160);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(21, 23);
            lblAccNum.TabIndex = 27;
            lblAccNum.Text = "---";
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel8.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel8.Location = new Point(66, 121);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(82, 23);
            guna2HtmlLabel8.TabIndex = 26;
            guna2HtmlLabel8.Text = "Paid With:";
            // 
            // continueBtn
            // 
            continueBtn.BackColor = Color.Transparent;
            continueBtn.BorderColor = Color.DarkSlateGray;
            continueBtn.BorderRadius = 15;
            continueBtn.BorderThickness = 2;
            continueBtn.CustomizableEdges = customizableEdges9;
            continueBtn.DisabledState.BorderColor = Color.DarkGray;
            continueBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            continueBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            continueBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            continueBtn.FillColor = Color.Teal;
            continueBtn.Font = new Font("Segoe UI Emoji", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            continueBtn.ForeColor = Color.White;
            continueBtn.Location = new Point(29, 294);
            continueBtn.Name = "continueBtn";
            continueBtn.ShadowDecoration.CustomizableEdges = customizableEdges10;
            continueBtn.Size = new Size(267, 42);
            continueBtn.TabIndex = 17;
            continueBtn.Text = "Continue to merchant";
            continueBtn.Click += continueBtn_Click;
            // 
            // lblCurrentBal
            // 
            lblCurrentBal.BackColor = Color.Transparent;
            lblCurrentBal.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCurrentBal.ForeColor = Color.DarkSlateGray;
            lblCurrentBal.Location = new Point(149, 248);
            lblCurrentBal.Name = "lblCurrentBal";
            lblCurrentBal.Size = new Size(21, 23);
            lblCurrentBal.TabIndex = 25;
            lblCurrentBal.Text = "---";
            // 
            // lblAmountSubtracted
            // 
            lblAmountSubtracted.BackColor = Color.Transparent;
            lblAmountSubtracted.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAmountSubtracted.ForeColor = Color.DarkSlateGray;
            lblAmountSubtracted.Location = new Point(149, 205);
            lblAmountSubtracted.Name = "lblAmountSubtracted";
            lblAmountSubtracted.Size = new Size(21, 23);
            lblAmountSubtracted.TabIndex = 24;
            lblAmountSubtracted.Text = "---";
            // 
            // lblcheqorsavings
            // 
            lblcheqorsavings.BackColor = Color.Transparent;
            lblcheqorsavings.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcheqorsavings.ForeColor = Color.DarkSlateGray;
            lblcheqorsavings.Location = new Point(149, 121);
            lblcheqorsavings.Name = "lblcheqorsavings";
            lblcheqorsavings.Size = new Size(21, 23);
            lblcheqorsavings.TabIndex = 23;
            lblcheqorsavings.Text = "---";
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.BackColor = Color.Transparent;
            guna2HtmlLabel7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel7.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel7.Location = new Point(20, 54);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(267, 23);
            guna2HtmlLabel7.TabIndex = 22;
            guna2HtmlLabel7.Text = "--------------------------------------------";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel6.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel6.Location = new Point(20, 248);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(128, 23);
            guna2HtmlLabel6.TabIndex = 21;
            guna2HtmlLabel6.Text = "Current Balance:";
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel5.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel5.Location = new Point(3, 205);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(145, 23);
            guna2HtmlLabel5.TabIndex = 20;
            guna2HtmlLabel5.Text = "Amount deducted:";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel4.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel4.Location = new Point(11, 160);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(137, 23);
            guna2HtmlLabel4.TabIndex = 19;
            guna2HtmlLabel4.Text = "Account Number:";
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel9.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel9.Location = new Point(37, 4);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(229, 34);
            guna2HtmlLabel9.TabIndex = 18;
            guna2HtmlLabel9.Text = "Transaction Receipt";
            // 
            // exitBtn
            // 
            exitBtn.CustomizableEdges = customizableEdges13;
            exitBtn.DisabledState.BorderColor = Color.DarkGray;
            exitBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            exitBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            exitBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            exitBtn.FillColor = Color.FromArgb(192, 0, 0);
            exitBtn.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitBtn.ForeColor = Color.White;
            exitBtn.Location = new Point(368, 1);
            exitBtn.Name = "exitBtn";
            exitBtn.ShadowDecoration.CustomizableEdges = customizableEdges14;
            exitBtn.Size = new Size(30, 28);
            exitBtn.TabIndex = 23;
            exitBtn.Text = "X";
            exitBtn.Click += exitBtn_Click;
            // 
            // WaterBillSec
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(400, 700);
            Controls.Add(exitBtn);
            Controls.Add(receiptPanel);
            Controls.Add(guna2HtmlLabel3);
            Controls.Add(cheqorsavings);
            Controls.Add(guna2HtmlLabel2);
            Controls.Add(waterChoice);
            Controls.Add(guna2HtmlLabel1);
            Controls.Add(PayBtn);
            Controls.Add(txtPayamount);
            FormBorderStyle = FormBorderStyle.None;
            Name = "WaterBillSec";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "WaterBillSec";
            Load += WaterBillSec_Load;
            receiptPanel.ResumeLayout(false);
            receiptPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2ComboBox waterChoice;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button PayBtn;
        private Guna.UI2.WinForms.Guna2TextBox txtPayamount;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2ComboBox cheqorsavings;
        private Guna.UI2.WinForms.Guna2Panel receiptPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblselectedCompany;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAccNum;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2Button continueBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblCurrentBal;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblAmountSubtracted;
        private Guna.UI2.WinForms.Guna2HtmlLabel lblcheqorsavings;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2Button exitBtn;
    }
}